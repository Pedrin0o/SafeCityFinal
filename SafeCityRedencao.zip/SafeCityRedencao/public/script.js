// ========== TEMA ==========

const botaoTema = document.getElementById('btn-tema');
const iconeTema = document.getElementById('icone-tema');

botaoTema.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');

  if (document.body.classList.contains('dark-mode')) {
    iconeTema.src = 'assets/icons/sun.png';
    iconeTema.alt = 'Modo Claro';
  } else {
    iconeTema.src = 'assets/icons/moon.png';
    iconeTema.alt = 'Modo Escuro';
  }
});


// ========== MAPA ==========

const map = L.map('map').setView([-8.0517, -34.8770], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

L.marker([-8.0517, -34.8770]).addTo(map)
  .bindPopup('Você está aqui!')
  .openPopup();


// ========== BUSCA DE ENDEREÇO ==========

document.getElementById('searchButton').addEventListener('click', () => {
  const query = document.getElementById('searchInput').value;
  if (!query) return;

  fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        const lat = data[0].lat;
        const lon = data[0].lon;

        map.setView([lat, lon], 15);
        L.marker([lat, lon]).addTo(map)
          .bindPopup(`Resultado: ${query}`)
          .openPopup();
      } else {
        alert('Local não encontrado. Tente outro endereço!');
      }
    })
    .catch(error => {
      console.error('Erro na busca:', error);
      alert('Erro ao buscar localização.');
    });
});

// Recuperar dados salvos do localStorage ao carregar
document.addEventListener("DOMContentLoaded", () => {
  const manutencoes = JSON.parse(localStorage.getItem("manutencoes")) || [];
  manutencoes.forEach(adicionarManutencaoNaLista);
});

const form = document.getElementById("form-manutencao");
const lista = document.getElementById("lista-manutencoes");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  // Obter valores
  const titulo = document.getElementById("titulo").value.trim();
  const descricao = document.getElementById("descricao").value.trim();
  const localizacao = document.getElementById("localizacao").value.trim();

  // Criar objeto de manutenção
  const novaManutencao = {
    id: Date.now(),
    titulo,
    descricao,
    localizacao,
    status: "Em andamento"
  };
//ADICIONAR NA LISTA

  // Salvar no localStorage
  const manutencoes = JSON.parse(localStorage.getItem("manutencoes")) || [];
  manutencoes.push(novaManutencao);
  localStorage.setItem("manutencoes", JSON.stringify(manutencoes));

  // Adicionar à lista na tela
  adicionarManutencaoNaLista(novaManutencao);

  // Limpar formulário
  form.reset();
});

// Função que cria o item HTML da manutenção
function adicionarManutencaoNaLista(manutencao) {
  const item = document.createElement("li");
  item.style.position = "relative";
  item.style.paddingBottom = "24px"; // espaço para o status

  item.innerHTML = `
    <strong>${manutencao.titulo}</strong><br/>
    <em>${manutencao.localizacao}</em><br/>
    <p>${manutencao.descricao}</p>
    <span class="status-label" data-status="${manutencao.status}">${manutencao.status}</span>
  `;

  lista.appendChild(item);
}

