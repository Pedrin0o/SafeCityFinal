const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');  // Importa o CORS
const app = express();
const PORT = 3000;

// Configurar CORS para permitir o acesso do frontend
app.use(cors({
    origin: 'http://127.0.0.1:5500'  // Altere isso para a URL do seu frontend
}));

app.use(express.json());

// Rota de cadastro
app.post('/register', (req, res) => {
    const { email, password, role, cpf } = req.body;

    // Verificar se todos os campos foram preenchidos
    if (!email || !password || !role || !cpf) {
        return res.status(400).json({ message: "Todos os campos são obrigatórios!" });
    }

    // Ajuste do caminho do arquivo para a pasta correta
    const filePath = path.join(__dirname, 'public', 'login', 'data', 'cadastros.json');

    let cadastros = [];
    
    // Verificar se o arquivo cadastros.json existe
    if (fs.existsSync(filePath)) {
        // Se o arquivo existir, ler os dados
        cadastros = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    // Adicionar o novo cadastro à lista
    cadastros.push({ email, password, role, cpf });

    // Escrever os dados de volta no arquivo
    fs.writeFileSync(filePath, JSON.stringify(cadastros, null, 2), 'utf8');

    // Retornar uma resposta de sucesso
    res.status(200).json({ message: "Cadastro realizado com sucesso!" });
});

// Rota para exibir os cadastros (para fins de debugging ou verificação)
app.get('/cadastros', (req, res) => {
    const filePath = path.join(__dirname, 'public', 'login', 'data', 'cadastros.json');
    
    if (fs.existsSync(filePath)) {
        const cadastros = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        res.status(200).json(cadastros);
    } else {
        res.status(404).json({ message: "Nenhum cadastro encontrado." });
    }
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    const filePath = path.join(__dirname, 'public', 'login', 'data', 'cadastros.json');

    if (!fs.existsSync(filePath)) {
        return res.status(500).json({ message: "Arquivo de cadastro não encontrado." });
    }

    const cadastros = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    const usuario = cadastros.find(user => user.email === email && user.password === password);

    if (!usuario) {
        return res.status(401).json({ message: "Credenciais inválidas." });
    }

    const isAdmin = email === "admsafecity1@gmail.com" && password === "admsafecity1";

    return res.status(200).json({
        message: "Login bem-sucedido.",
        usuario: {
            email: usuario.email,
            role: usuario.role,
            cpf: usuario.cpf,
            isAdmin: isAdmin
        }
    });
});
// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});

